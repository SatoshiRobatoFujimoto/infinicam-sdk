var searchData=
[
  ['ppuc_5fdetect_5finfo',['PPUC_DETECT_INFO',['../_p_u_c_l_i_b_8h.html#a36b0cb586929ef8781dea0fdfbb03ad7',1,'PUCLIB.h']]],
  ['ppuc_5fhandle',['PPUC_HANDLE',['../_p_u_c_l_i_b_8h.html#ac931f9c87e1e91ce807def0afd7c7f0c',1,'PUCLIB.h']]],
  ['ppuc_5freso_5flimit_5finfo',['PPUC_RESO_LIMIT_INFO',['../_p_u_c_l_i_b_8h.html#a0ea418d1571fcac7a167d66d617733bb',1,'PUCLIB.h']]],
  ['ppuc_5fxfer_5fdata_5finfo',['PPUC_XFER_DATA_INFO',['../_p_u_c_l_i_b_8h.html#a25768998e7ed615793951c6c4f15dab7',1,'PUCLIB.h']]],
  ['puc_5fhandle',['PUC_HANDLE',['../_p_u_c_l_i_b_8h.html#a55697c0ca776ce59b098d1d0ea661466',1,'PUCLIB.h']]]
];
