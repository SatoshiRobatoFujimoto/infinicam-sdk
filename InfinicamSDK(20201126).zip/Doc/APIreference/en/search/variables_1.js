var searchData=
[
  ['pdata',['pData',['../struct_p_u_c___x_f_e_r___d_a_t_a___i_n_f_o.html#ae5481a39332aa6d2bf5e31c8732d42fa',1,'PUC_XFER_DATA_INFO']]]
];
