#pragma once

extern BOOL SelectFolderDialog(HWND hwndOwner, LPTSTR initFolder, LPTSTR selectedFolder);
extern CString MakeUpper(LPCTSTR str);


