var searchData=
[
  ['puc_5fdetect_5finfo',['PUC_DETECT_INFO',['../struct_p_u_c___d_e_t_e_c_t___i_n_f_o.html',1,'']]],
  ['puc_5freso_5flimit_5finfo',['PUC_RESO_LIMIT_INFO',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html',1,'']]],
  ['puc_5fxfer_5fdata_5finfo',['PUC_XFER_DATA_INFO',['../struct_p_u_c___x_f_e_r___d_a_t_a___i_n_f_o.html',1,'']]]
];
