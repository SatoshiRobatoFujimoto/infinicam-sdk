var searchData=
[
  ['ndatasize',['nDataSize',['../struct_p_u_c___x_f_e_r___d_a_t_a___i_n_f_o.html#a8999ae566acb89ec7cb3f1d671d09536',1,'PUC_XFER_DATA_INFO']]],
  ['ndevicecount',['nDeviceCount',['../struct_p_u_c___d_e_t_e_c_t___i_n_f_o.html#abbe3b099ae5a0489a10b427700b71c41',1,'PUC_DETECT_INFO']]],
  ['ndevicenolist',['nDeviceNoList',['../struct_p_u_c___d_e_t_e_c_t___i_n_f_o.html#adaf399165aa3121fd6166e4b9f04ebf9',1,'PUC_DETECT_INFO']]],
  ['nmaxheight',['nMaxHeight',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#a4971ec18d79a1467bcfdf271c31f40d3',1,'PUC_RESO_LIMIT_INFO']]],
  ['nmaxwidth',['nMaxWidth',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#a8cbec97f0db46ea7fd881a19c16012b4',1,'PUC_RESO_LIMIT_INFO']]],
  ['nminheight',['nMinHeight',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#ab34e89321e5114a1035a6e75cc781bc7',1,'PUC_RESO_LIMIT_INFO']]],
  ['nminwidth',['nMinWidth',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#aee0683fe933e3067817bd9446c7b7b95',1,'PUC_RESO_LIMIT_INFO']]],
  ['nsequenceno',['nSequenceNo',['../struct_p_u_c___x_f_e_r___d_a_t_a___i_n_f_o.html#aca1747f6b7a1fb5be58a5aeaf4ccc28e',1,'PUC_XFER_DATA_INFO']]],
  ['nunitheight',['nUnitHeight',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#ab0d0df4bbd1ac9337322081ac15e15c6',1,'PUC_RESO_LIMIT_INFO']]],
  ['nunitwidth',['nUnitWidth',['../struct_p_u_c___r_e_s_o___l_i_m_i_t___i_n_f_o.html#a241afb1ee138c73316d94944dab2a4e4',1,'PUC_RESO_LIMIT_INFO']]]
];
