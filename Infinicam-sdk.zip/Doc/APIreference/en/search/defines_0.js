var searchData=
[
  ['puc_5fchk_5ffailed',['PUC_CHK_FAILED',['../_p_u_c_l_i_b_8h.html#ad16090581124a03fae7db4189ba5e0fa',1,'PUCLIB.h']]],
  ['puc_5fchk_5fsucceeded',['PUC_CHK_SUCCEEDED',['../_p_u_c_l_i_b_8h.html#a1ccd7b6bb04262268a036a740c6f3a47',1,'PUCLIB.h']]],
  ['puc_5fmax_5fdevice',['PUC_MAX_DEVICE',['../_p_u_c_l_i_b_8h.html#a840d58cb9789894618e9afec92010758',1,'PUCLIB.h']]],
  ['puc_5fmax_5flen',['PUC_MAX_LEN',['../_p_u_c_l_i_b_8h.html#a91f254a1038beb17e1d98fab0e9bb075',1,'PUCLIB.h']]],
  ['puc_5fmax_5fring_5fbuf_5fcount',['PUC_MAX_RING_BUF_COUNT',['../_p_u_c_l_i_b_8h.html#a0b4cea346c223169252a58dbd37e0552',1,'PUCLIB.h']]],
  ['puc_5fmin_5fring_5fbuf_5fcount',['PUC_MIN_RING_BUF_COUNT',['../_p_u_c_l_i_b_8h.html#aed9c526f5d57d4552cd9d21cdd8d434c',1,'PUCLIB.h']]],
  ['puc_5fq_5fcount',['PUC_Q_COUNT',['../_p_u_c_l_i_b_8h.html#a569fc4d8e4430bdde7797b5391a5617b',1,'PUCLIB.h']]],
  ['puc_5fsync_5fout_5fmagnification_5f0_5f5',['PUC_SYNC_OUT_MAGNIFICATION_0_5',['../_p_u_c_l_i_b_8h.html#a24455265da59d28c1806db5d327a90c8',1,'PUCLIB.h']]],
  ['puc_5fxfer_5ftimeout_5fauto',['PUC_XFER_TIMEOUT_AUTO',['../_p_u_c_l_i_b_8h.html#ad4cf81a4377d2e960571573025cf27b8',1,'PUCLIB.h']]],
  ['puc_5fxfer_5ftimeout_5finfinite',['PUC_XFER_TIMEOUT_INFINITE',['../_p_u_c_l_i_b_8h.html#a1d032ea000e0bffdefb874aa045353ac',1,'PUCLIB.h']]]
];
