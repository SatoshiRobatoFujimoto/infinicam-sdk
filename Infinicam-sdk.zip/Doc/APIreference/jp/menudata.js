/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"総合概要",url:"index.html"},
{text:"データ構造",url:"annotated.html",children:[
{text:"データ構造",url:"annotated.html"},
{text:"データ構造索引",url:"classes.html"},
{text:"データフィールド",url:"functions.html",children:[
{text:"全て",url:"functions.html"},
{text:"変数",url:"functions_vars.html"}]}]},
{text:"ファイル",url:"files.html",children:[
{text:"ファイル一覧",url:"files.html"},
{text:"大域各種",url:"globals.html",children:[
{text:"全て",url:"globals.html",children:[
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"}]},
{text:"関数",url:"globals_func.html",children:[
{text:"p",url:"globals_func.html#index_p"}]},
{text:"型定義",url:"globals_type.html"},
{text:"列挙型",url:"globals_enum.html"},
{text:"列挙値",url:"globals_eval.html",children:[
{text:"p",url:"globals_eval.html#index_p"}]},
{text:"マクロ定義",url:"globals_defs.html"}]}]}]}
