var indexSectionsWithContent =
{
  0: "npr",
  1: "p",
  2: "p",
  3: "p",
  4: "np",
  5: "pr",
  6: "p",
  7: "p",
  8: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "型定義",
  6: "列挙型",
  7: "列挙値",
  8: "マクロ定義"
};

